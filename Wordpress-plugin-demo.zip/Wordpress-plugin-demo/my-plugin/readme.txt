=== My Plugin ===
Contributors: yourusername
Donate link: https://example.com/donate
Tags: example, demo, plugin
Requires at least: 5.0
Tested up to: 6.3
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
This is a simple plugin example for demonstration purposes.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/my-plugin/` directory.
2. Activate the plugin through the 'Plugins' screen in WordPress.

== Changelog ==
= 1.0.0 =
* Initial release.